import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadChildren: () => import('./pages/home/home.module').then(m => m.HomePageModule)
  },
  {
    path: 'bar-details/:id',
    loadChildren: () => import('./pages/bar-details/bar-details.module').then(m => m.BarDetailsPageModule)
  },
  {
    path: 'bar-tab',
    loadChildren: () => import('./pages/bar-tab/bar-tab.module').then(m => m.BarTabPageModule)
  },
  {
    path: 'bars-list',
    loadChildren: () => import('./pages/bars-list/bars-list.module').then(m => m.BarsListPageModule)
  },
  {
    path: 'user-profile',
    loadChildren: () => import('./pages/user-profile/user-profile.module').then(m => m.UserProfilePageModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
