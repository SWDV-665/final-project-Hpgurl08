import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

// Import the Camera and QRScanner
import { Camera } from '@ionic-native/camera/ngx';
/*import { QRScanner } from '@ionic-native/qr-scanner/ngx';*/

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    AppRoutingModule
  ],
  providers: [
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    Camera, // Add Camera to providers
    /*RScanner // Add QRScanner to providers*/
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
