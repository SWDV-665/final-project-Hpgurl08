import { Injectable } from '@angular/core';

interface User {
  name: string;
  paymentInfo: string;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private user: User = {
    name: '',
    paymentInfo: ''
  };

  constructor() { }

  getUserProfile(): User {
    return this.user;
  }

  saveUserProfile(updatedUser: User): void {
    this.user = updatedUser;
  }
}