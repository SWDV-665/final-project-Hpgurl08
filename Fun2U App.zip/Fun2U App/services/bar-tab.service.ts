import { Injectable } from '@angular/core';

interface Bar {
  id: number;
  name: string;
  location: string;
  description: string;
  image: string;
  drinks: { name: string; price: number }[];
}

@Injectable({
  providedIn: 'root'
})
export class BarsService {
  private bars: Bar[] = [
    // Sample data - you can replace this with real data
    {
      id: 1,
      name: 'The Cozy Pub',
      location: 'Downtown',
      description: 'A friendly place to enjoy your evening.',
      image: 'assets/images/bar1.jpg',
      drinks: [
        { name: 'Beer', price: 5 },
        { name: 'Cocktail', price: 8 },
        { name: 'Pepsi', price: 3 },
        { name: 'Whiskey', price: 6 },
        { name: 'Vodka', price: 8 },
        { name: 'Water', price: 2 },
        { name: 'Cofee', price: 5 }
        // Add more drinks here
      ]
    },
    {
      id: 2,
      name: 'The Greymans',
      location: 'East Texas',
      description: 'Stay jolly',
      image: 'assets/images/bar1.jpg',
      drinks: [
        { name: 'Beer', price: 5 },
        { name: 'Red wine', price: 30 },
        { name: 'Coke', price: 4 },
        { name: 'Milkshakes', price: 4 },
        { name: 'Whiskey on rocks', price: 8 },
        { name: 'Water', price: 2 },
        { name: 'Cofee', price: 5 },
        { name: 'Tea', price: 5 }
        // Add more drinks here
      ]
    }
    // Add more bars here
  ];

  constructor() { }

  getBars(): Bar[] {
    return this.bars;
  }

  getBarDetails(barId: number): Bar | undefined {
    return this.bars.find(bar => bar.id === barId);
  }
}