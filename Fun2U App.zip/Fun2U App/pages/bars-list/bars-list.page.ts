import { Component, OnInit } from '@angular/core';
import { BarsService } from '../../services/bars.service';

interface Bar {
  id: number;
  name: string;
  location: string;
  description: string;
  image: string;
}

@Component({
  selector: 'app-bars-list',
  templateUrl: './bars-list.page.html',
  styleUrls: ['./bars-list.page.scss'],
})
export class BarsListPage implements OnInit {
  bars: Bar[] = [];

  constructor(private barsService: BarsService) {}

  ngOnInit() {
    this.bars = this.barsService.getBars();
  }
}