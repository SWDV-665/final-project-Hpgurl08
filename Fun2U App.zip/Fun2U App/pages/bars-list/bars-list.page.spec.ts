import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BarsListPage } from './bars-list.page';

describe('BarsListPage', () => {
  let component: BarsListPage;
  let fixture: ComponentFixture<BarsListPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(BarsListPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
