import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BarTabPage } from './bar-tab.page';

const routes: Routes = [
  {
    path: '',
    component: BarTabPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BarTabPageRoutingModule {}
