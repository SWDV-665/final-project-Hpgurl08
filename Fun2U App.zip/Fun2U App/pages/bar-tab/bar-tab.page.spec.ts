import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BarTabPage } from './bar-tab.page';

describe('BarTabPage', () => {
  let component: BarTabPage;
  let fixture: ComponentFixture<BarTabPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(BarTabPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
