import { Component } from '@angular/core';

interface Order {
  item: string;
  price: number;
}

@Component({
  selector: 'app-bar-tab',
  templateUrl: 'bar-tab.page.html',
  styleUrls: ['bar-tab.page.scss'],
})
export class BarTabPage {
  tabOpened = false;
  currentOrders: Order[] = [];

  constructor() {}

  openTab() {
    this.tabOpened = true;
    // Simulating adding orders
    this.currentOrders = [
      { item: 'Cocktail', price: 8 },
      { item: 'Beer', price: 5 },
      // Add more sample orders here
    ];
  }

  closeTab() {
    this.tabOpened = false;
    this.currentOrders = [];
    console.log('Tab Closed and Orders Cleared');
  }

  // You can add more functions for order management
}
