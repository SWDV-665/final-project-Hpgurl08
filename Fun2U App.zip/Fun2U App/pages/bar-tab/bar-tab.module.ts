import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { BarTabPageRoutingModule } from './bar-tab-routing.module';
import { BarTabPage } from './bar-tab.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BarTabPageRoutingModule
  ],
  declarations: [BarTabPage]
})
export class BarTabPageModule {}
