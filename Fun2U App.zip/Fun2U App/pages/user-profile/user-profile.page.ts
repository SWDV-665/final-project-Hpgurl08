import { Component } from '@angular/core';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.page.html',
  styleUrls: ['./user-profile.page.scss'],
})
export class UserProfilePage {
  user = { name: '', paymentInfo: '' };

  constructor(private userService: UserService) {}

  ngOnInit() {
    this.getUserData();
  }

  getUserData() {
    this.user = this.userService.getUserProfile();
  }

  saveProfile() {
    this.userService.saveUserProfile(this.user);
    console.log('Profile saved:', this.user);
  }
}
