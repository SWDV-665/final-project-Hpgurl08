import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BarsService } from '../../services/bars.service';

@Component({
  selector: 'app-bar-details',
  templateUrl: 'bar-details.page.html',
  styleUrls: ['bar-details.page.scss'],
})
export class BarDetailsPage implements OnInit {
  bar: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private barsService: BarsService
  ) {}

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      const barId = +params['id'];
      this.bar = this.barsService.getBarDetails(barId);
    });
  }
}